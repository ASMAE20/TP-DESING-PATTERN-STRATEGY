package designPatternStrategy;
import java.util.List;

public class Context {
	SortingStrategy strategy;
	public Context(SortingStrategy strategy) {
		this.strategy=strategy;
	}
	public void trier(List<Produit> produits) {
		 strategy.trier(produits);
	}
	
	

}
