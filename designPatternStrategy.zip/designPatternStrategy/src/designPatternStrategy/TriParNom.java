package designPatternStrategy;

import java.util.List;

public class TriParNom implements SortingStrategy {

	private void swap(List<Produit> produits,int i,int j){
		Produit temp=produits.get(i);
		produits.set(i,produits.get(j));
		produits.set(j,temp);



	}
	private void bubbleSort(List<Produit> produits){

		for (int i = 0; i < produits.size(); i++) {
			for (int j = i + 1; j < produits.size(); j++) {

				// to compare one string with other strings
				if (produits.get(i).getNom().compareTo(produits.get(j).getNom()) > 0) {
					// swapping
					swap(produits,i,j);
				}
			}
		}
		for(Produit produit:produits){
			System.out.println(produit.getNom()+"   "+produit.getPrix()+"\n");
		}
	}

	@Override
	public void trier(List<Produit> produits){
		bubbleSort(produits);
		
	}

}
