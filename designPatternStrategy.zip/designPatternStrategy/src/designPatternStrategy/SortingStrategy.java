package designPatternStrategy;

import java.util.List;

public interface SortingStrategy {
	 void trier(List<Produit> produits);

}
