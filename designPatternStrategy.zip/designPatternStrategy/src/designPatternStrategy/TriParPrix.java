package designPatternStrategy;

import java.util.List;

public class TriParPrix  implements SortingStrategy {
	private void swap(List<Produit> produits,int i,int j){
		Produit temp=produits.get(i);
		produits.set(i,produits.get(j));
		produits.set(j,temp);



	}
	private void bubbleSort(List<Produit> arr)
	{

		int n = arr.size();
		for (int i = 0; i < n - 1; i++)
			for (int j = 0; j < n - i - 1; j++)
				if (arr.get(j).getPrix() > arr.get(j + 1).getPrix()) {
					swap(arr,j,j+1);
				}
		for(Produit produit:arr){
			System.out.println(produit.getNom()+"   "+produit.getPrix()+"\n");
		}
	}

	@Override
	public void trier(List<Produit>produits){
	this.bubbleSort(produits);
		
		
	}

}