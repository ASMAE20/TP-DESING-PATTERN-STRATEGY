package designPatternStrategy;

import java.util.ArrayList;
import java.util.List;

public class Main {
	public static void main(String[] args) {
		List<Produit> produits=new ArrayList<>() ;
		produits.add(new Produit("d", 12))	;
		produits.add(new Produit("c", 1));
		produits.add(new Produit("a", 2));
		produits.add(new Produit("b", 54));
		produits.add(new Produit("f", 23));
		produits.add(new Produit("e", 5));

		System.out.println("Liste n'est pas encore triee :\n");
		for(Produit produit:produits){
			System.out.println(produit.getNom()+"   "+produit.getPrix()+"\n");
		}


		System.out.println("Liste trier par prix :\n");
		Context ctx=new Context(new TriParPrix());
		ctx.trier(produits);



		System.out.println("Liste triee par nom  :\n");
		ctx=new Context(new TriParNom());
		ctx.trier(produits);
		
	}
	
}
