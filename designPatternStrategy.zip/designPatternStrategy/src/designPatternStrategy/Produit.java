package designPatternStrategy;

public class Produit {
	String nom;
	int prix;
	public Produit() {
		
	}
public Produit(String nom,int prix) {
	this.nom=nom;
	this.prix=prix;
		
	}

	public int getPrix() {
		return prix;
	}

	public String getNom() {
		return nom;
	}
}
