
public interface Strategy {
	public void sort(int [] numbers);

}
